﻿namespace $safeprojectname$.Dtos.Todo
{
    public class NewTodoDto
    {
        public string Label { get; set; }
    }
}