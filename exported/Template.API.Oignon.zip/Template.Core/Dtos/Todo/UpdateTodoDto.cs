﻿namespace $safeprojectname$.Dtos.Todo
{
    public class UpdateTodoDto : NewTodoDto
    {
    }
}